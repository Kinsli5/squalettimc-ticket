
"""
Discord UI Modals for Ticket System
Handles ticket form submissions and user interactions
"""
import discord
from datetime import datetime

class TicketModal(discord.ui.Modal, title='📋 Informazioni Ticket'):
    """Modal form for ticket information"""
    
    def __init__(self, channel_id=None):
        super().__init__()
        self.channel_id = channel_id
    
    minecraft_nick = discord.ui.TextInput(
        label='Il tuo nick di Minecraft',
        placeholder='Inserisci il tuo nickname di Minecraft...',
        required=True,
        max_length=16,
        style=discord.TextStyle.short
    )
    
    reason = discord.ui.TextInput(
        label='Motivo apertura ticket',
        placeholder='Descrivi brevemente il motivo per cui hai aperto questo ticket...',
        required=True,
        max_length=1000,
        style=discord.TextStyle.paragraph
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle form submission"""
        # Get the bot instance from the interaction
        bot = interaction.client
        
        # Use stored channel_id if available, otherwise use current channel
        channel_id = self.channel_id if hasattr(self, 'channel_id') and self.channel_id else interaction.channel.id
        
        # Update database with form data
        success = bot.db.update_ticket_form_data(
            channel_id,
            self.minecraft_nick.value,
            self.reason.value
        )
        
        if success:
            # Get the ticket channel
            ticket_channel = bot.get_channel(channel_id)
            if not ticket_channel:
                await interaction.response.send_message(
                    "❌ Errore: canale ticket non trovato.",
                    ephemeral=True
                )
                return
            
            # Create comprehensive ticket information message
            embed = discord.Embed(
                title="🎫 Ticket Creato con Successo",
                description="Le informazioni sono state registrate correttamente.",
                color=0x00FF00
            )
            
            # Add all ticket information in organized fields
            embed.add_field(
                name="👤 Utente", 
                value=interaction.user.mention, 
                inline=True
            )
            embed.add_field(
                name="🎮 Nick Minecraft", 
                value=f"`{self.minecraft_nick.value}`", 
                inline=True
            )
            embed.add_field(
                name="📅 Data Creazione", 
                value=f"<t:{int(datetime.now().timestamp())}:F>", 
                inline=True
            )
            embed.add_field(
                name="📝 Descrizione del Problema", 
                value=self.reason.value, 
                inline=False
            )
            embed.add_field(
                name="⏰ Stato", 
                value="🟢 Aperto - In attesa di risposta dello staff", 
                inline=False
            )
            
            embed.set_footer(
                text="Lo staff ti risponderà il prima possibile. Fornisci dettagli aggiuntivi se necessario.",
                icon_url=interaction.user.display_avatar.url
            )
            embed.set_thumbnail(url=interaction.user.display_avatar.url)
            
            # Send comprehensive message to ticket channel
            await ticket_channel.send(
                f"🎫 **Nuovo Ticket Aperto da {interaction.user.display_name}**\n"
                f"Tutte le informazioni sono state raccolte correttamente.",
                embed=embed
            )
            
            # Respond to modal interaction
            await interaction.response.send_message(
                f"✅ Ticket creato con successo: {ticket_channel.mention}\n"
                "Le tue informazioni sono state registrate!",
                ephemeral=True
            )
            
            # Notify staff if configured
            guild_config = bot.db.get_guild_config(interaction.guild.id)
            if guild_config and guild_config.get('staff_role_id'):
                staff_role = interaction.guild.get_role(int(guild_config['staff_role_id']))
                if staff_role:
                    staff_embed = discord.Embed(
                        title="🔔 Nuovo Ticket Completato",
                        description=f"Un nuovo ticket è stato aperto e compilato da {interaction.user.mention} in {ticket_channel.mention}",
                        color=0x00FFFF
                    )
                    await ticket_channel.send(f"{staff_role.mention}", embed=staff_embed, delete_after=10)
        else:
            await interaction.response.send_message(
                "❌ Errore nel salvare le informazioni. Riprova più tardi.",
                ephemeral=True
            )
    
    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        """Handle modal errors"""
        print(f"❌ Modal error: {error}")
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "❌ Si è verificato un errore durante l'invio del modulo. Riprova più tardi.",
                ephemeral=True
            )

class TicketEditModal(discord.ui.Modal, title='✏️ Modifica Informazioni Ticket'):
    """Modal for editing ticket information"""
    
    def __init__(self, current_nick=None, current_reason=None):
        super().__init__()
        
        # Pre-fill with current values if available
        if current_nick:
            self.minecraft_nick.default = current_nick
        if current_reason:
            self.reason.default = current_reason
    
    minecraft_nick = discord.ui.TextInput(
        label='Il tuo nick di Minecraft',
        placeholder='Inserisci il tuo nickname di Minecraft...',
        required=True,
        max_length=16,
        style=discord.TextStyle.short
    )
    
    reason = discord.ui.TextInput(
        label='Motivo apertura ticket',
        placeholder='Descrivi brevemente il motivo per cui hai aperto questo ticket...',
        required=True,
        max_length=1000,
        style=discord.TextStyle.paragraph
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle edit form submission"""
        bot = interaction.client
        
        # Update database with new form data
        success = bot.db.update_ticket_form_data(
            interaction.channel.id,
            self.minecraft_nick.value,
            self.reason.value
        )
        
        if success:
            embed = discord.Embed(
                title="✅ Informazioni Aggiornate",
                description="Le informazioni del ticket sono state aggiornate con successo.",
                color=bot.config.get_embed_color('primary')
            )
            embed.add_field(name="🎮 Nick Minecraft", value=self.minecraft_nick.value, inline=True)
            embed.add_field(name="📝 Motivo", value=self.reason.value, inline=False)
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message(
                "❌ Errore nell'aggiornamento delle informazioni.",
                ephemeral=True
            )
    
    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        """Handle modal errors"""
        print(f"❌ Edit modal error: {error}")
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "❌ Si è verificato un errore durante l'aggiornamento. Riprova più tardi.",
                ephemeral=True
            )

class CloseTicketModal(discord.ui.Modal, title='🔒 Chiusura Ticket'):
    """Modal for closing tickets with reason"""
    
    def __init__(self):
        super().__init__()
    
    close_reason = discord.ui.TextInput(
        label='Motivo chiusura (opzionale)',
        placeholder='Inserisci il motivo della chiusura del ticket...',
        required=False,
        max_length=500,
        style=discord.TextStyle.paragraph
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle close ticket form submission"""
        bot = interaction.client
        channel = interaction.channel
        
        # Get ticket info
        ticket = bot.db.get_ticket(channel_id=channel.id)
        if not ticket:
            await interaction.response.send_message(
                "❌ Questo non è un canale ticket valido.",
                ephemeral=True
            )
            return
        
        # Close ticket with reason
        success = bot.db.close_ticket(channel.id, interaction.user.id)
        
        if success:
            # Update with close reason if provided
            if self.close_reason.value:
                bot.db.add_ticket_note(channel.id, f"Chiuso: {self.close_reason.value}", interaction.user.id)
            
            embed = discord.Embed(
                title="🔒 Ticket Chiuso",
                description=f"Questo ticket è stato chiuso da {interaction.user.mention}.",
                color=bot.config.get_embed_color('error')
            )
            
            if self.close_reason.value:
                embed.add_field(name="📝 Motivo", value=self.close_reason.value, inline=False)
            
            embed.add_field(name="⏰ Eliminazione", value="Il canale verrà eliminato tra 10 secondi.", inline=False)
            
            await interaction.response.send_message(embed=embed)
            
            # Log the closure
            await bot.ticket_system.log_ticket_action(
                interaction.guild,
                "Ticket Chiuso",
                f"{interaction.user.mention} ha chiuso {channel.mention}"
                + (f"\nMotivo: {self.close_reason.value}" if self.close_reason.value else "")
            )
            
            # Delete channel after delay
            import asyncio
            await asyncio.sleep(10)
            try:
                await channel.delete(reason=f"Ticket chiuso da {interaction.user}")
            except Exception as e:
                print(f"❌ Error deleting channel: {e}")
        else:
            await interaction.response.send_message(
                "❌ Errore nella chiusura del ticket.",
                ephemeral=True
            )
    
    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        """Handle modal errors"""
        print(f"❌ Close modal error: {error}")
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "❌ Si è verificato un errore durante la chiusura. Riprova più tardi.",
                ephemeral=True
            )
