from flask import Flask, jsonify
from threading import Thread
import time
import requests
import os

app = Flask('')

@app.route('/')
def home():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Discord Bot - Always Online</title>
        <meta http-equiv="refresh" content="60">
        <style>
            body { font-family: Arial; text-align: center; padding: 50px; background: #2c2f33; color: white; }
            h1 { color: #7289da; }
        </style>
    </head>
    <body>
        <h1>🤖 Discord Ticket Bot</h1>
        <h2>✅ ONLINE 24/7</h2>
        <p>Status: Attivo e funzionante</p>
        <p>Hosting: Gratuito su Replit</p>
        <p>Auto-refresh: Ogni 60 secondi</p>
        <hr>
        <p><small>Mantieni questa pagina nei preferiti per monitoraggio</small></p>
    </body>
    </html>
    """

@app.route('/ping')
def ping():
    return jsonify({"status": "alive", "time": time.time()})

@app.route('/health')
def health():
    return jsonify({"bot": "online", "uptime": time.time()})

def run():
    app.run(host='0.0.0.0', port=8000, debug=False)

def keep_alive():
    t = Thread(target=run, daemon=True)
    t.start()

def auto_ping():
    """Sistema di auto-ping interno per prevenire sleep - REPLIT CORE SIMULATION"""
    def ping_loop():
        while True:
            try:
                time.sleep(180)  # Ping ogni 3 minuti (più aggressivo)
                
                # Multi-ping system per simulare Reserved VM
                ping_urls = [
                    "http://0.0.0.0:3000/ping",
                    "http://0.0.0.0:5000/ping", 
                    "http://0.0.0.0:8000/ping",
                    "http://127.0.0.1:3000/health",
                    "http://127.0.0.1:5000/health",
                    "http://127.0.0.1:8000/health"
                ]
                
                success_count = 0
                for url in ping_urls:
                    try:
                        response = requests.get(url, timeout=5)
                        if response.status_code == 200:
                            success_count += 1
                    except:
                        pass
                
                print(f"🔄 CORE-MODE: {success_count}/{len(ping_urls)} services active - {time.strftime('%H:%M:%S')}")
                
                # Simula traffico costante per prevenire sleep
                for i in range(3):
                    try:
                        requests.get("http://0.0.0.0:3000/", timeout=3)
                        time.sleep(30)
                    except:
                        pass
                        
            except Exception as e:
                print(f"⚠️ CORE-MODE ping failed: {e}")
                time.sleep(30)
    
    ping_thread = Thread(target=ping_loop, daemon=True)
    ping_thread.start()
    print("🎯 REPLIT CORE SIMULATION MODE ACTIVATED!")
