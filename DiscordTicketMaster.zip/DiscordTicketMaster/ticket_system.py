"""
Ticket System Management
Handles ticket creation, closure, and management
"""
import discord
from discord.ext import commands
import asyncio
from datetime import datetime
from modals import TicketModal

class TicketSystem:
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
        self.config = bot.config
    
    async def create_ticket_panel(self, channel):
        """Create the main ticket panel with button"""
        embed = discord.Embed(
            title="🎫 Sistema Ticket",
            description="Clicca il pulsante qui sotto per aprire un nuovo ticket.\n\n"
                       "**Quando aprire un ticket:**\n"
                       "• Hai bisogno di assistenza\n"
                       "• Vuoi segnalare un problema\n"
                       "• Hai domande per lo staff\n"
                       "• Richieste particolari",
            color=self.config.get_embed_color('primary')
        )
        embed.set_footer(text="Clicca il pulsante per iniziare")
        embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/🎫.png")
        
        # Create button
        view = discord.ui.View(timeout=None)
        button = discord.ui.Button(
            label="Apri Ticket",
            emoji="🎫",
            style=discord.ButtonStyle.primary,
            custom_id="create_ticket"
        )
        view.add_item(button)
        
        try:
            await channel.send(embed=embed, view=view)
            return True
        except Exception as e:
            print(f"❌ Error creating ticket panel: {e}")
            return False
    
    async def create_ticket_button(self, interaction):
        """Handle ticket creation from button click"""
        guild = interaction.guild
        user = interaction.user
        
        # Check if user already has open tickets
        user_tickets = self.db.get_user_tickets(user.id, guild.id, 'open')
        max_tickets = self.config.get('ticket.max_tickets_per_user', 3)
        
        if len(user_tickets) >= max_tickets:
            embed = discord.Embed(
                title="❌ Limite Raggiunto",
                description=f"Hai già {len(user_tickets)} ticket aperti.\nChiudi un ticket esistente prima di aprirne uno nuovo.",
                color=self.config.get_embed_color('error')
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Get guild configuration
        guild_config = self.db.get_guild_config(guild.id)
        
        # Find or create ticket category
        category = None
        if guild_config and guild_config.get('ticket_category_id'):
            category = guild.get_channel(int(guild_config['ticket_category_id']))
        
        if not category:
            # Create default category
            try:
                category = await guild.create_category(
                    name=self.config.get('ticket.default_category_name', '🎫 TICKETS'),
                    reason="Ticket system setup"
                )
                self.db.update_guild_config(guild.id, ticket_category_id=str(category.id))
            except Exception as e:
                print(f"❌ Error creating ticket category: {e}")
                await interaction.response.send_message(
                    "❌ Errore nella creazione della categoria ticket. Contatta un amministratore.",
                    ephemeral=True
                )
                return
        
        # Generate ticket number
        ticket_counter = self.db.increment_ticket_counter(guild.id)
        ticket_name = f"ticket-{ticket_counter:04d}"
        
        # Create ticket channel
        try:
            # Set up permissions
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                user: discord.PermissionOverwrite(
                    read_messages=True,
                    send_messages=True,
                    embed_links=True,
                    attach_files=True,
                    read_message_history=True
                ),
                guild.me: discord.PermissionOverwrite(
                    read_messages=True,
                    send_messages=True,
                    manage_messages=True,
                    embed_links=True,
                    attach_files=True,
                    read_message_history=True
                )
            }
            
            # Add staff role permissions if configured
            if guild_config and guild_config.get('staff_role_id'):
                staff_role = guild.get_role(int(guild_config['staff_role_id']))
                if staff_role:
                    overwrites[staff_role] = discord.PermissionOverwrite(
                        read_messages=True,
                        send_messages=True,
                        manage_messages=True,
                        embed_links=True,
                        attach_files=True,
                        read_message_history=True
                    )
            
            # Create the channel
            ticket_channel = await category.create_text_channel(
                name=ticket_name,
                overwrites=overwrites,
                topic=f"Ticket di {user.display_name} • ID: {user.id}",
                reason=f"Ticket creato da {user}"
            )
            
            # Create ticket record in database
            ticket_id = f"{guild.id}-{ticket_counter:04d}"
            self.db.create_ticket(ticket_id, str(user.id), str(ticket_channel.id), str(guild.id))
            
            # Send welcome message and form
            await self.send_ticket_welcome(ticket_channel, user)
            
            # Show modal immediately when ticket is created
            from modals import TicketModal
            modal = TicketModal()
            modal.channel_id = ticket_channel.id  # Store channel ID for later use
            await interaction.response.send_modal(modal)
            
            # Log ticket creation
            await self.log_ticket_action(guild, "Ticket Creato", f"{user.mention} ha aperto {ticket_channel.mention}")
            
        except Exception as e:
            print(f"❌ Error creating ticket channel: {e}")
            await interaction.response.send_message(
                "❌ Errore nella creazione del ticket. Riprova più tardi.",
                ephemeral=True
            )
    
    async def send_ticket_welcome(self, channel, user):
        """Send welcome message and modal trigger in ticket channel"""
        embed = discord.Embed(
            title="🎫 Benvenuto nel tuo Ticket!",
            description=self.config.get_message('ticket_created'),
            color=self.config.get_embed_color('primary')
        )
        embed.add_field(
            name="📋 Prossimi Passi",
            value="1️⃣ Compila il modulo che è apparso\n"
                  "2️⃣ Attendi la risposta dello staff\n"
                  "3️⃣ Usa `/close` o il pulsante per chiudere",
            inline=False
        )
        embed.set_footer(text=f"Ticket di {user.display_name}", icon_url=user.display_avatar.url)
        
        # Create control buttons (no form button since modal appears immediately)
        view = discord.ui.View(timeout=None)
        
        claim_button = discord.ui.Button(
            label="📌 Claim",
            emoji="📌",
            style=discord.ButtonStyle.secondary,
            custom_id=f"claim_ticket_{channel.id}"
        )
        
        close_button = discord.ui.Button(
            label="🔒 Chiudi Ticket",
            emoji="🔒",
            style=discord.ButtonStyle.danger,
            custom_id=f"close_ticket_{channel.id}"
        )
        
        view.add_item(claim_button)
        view.add_item(close_button)
        
        try:
            await channel.send(content=f"👋 Ciao {user.mention}!", embed=embed, view=view)
        except Exception as e:
            print(f"❌ Error sending welcome message: {e}")
    

    
    async def handle_claim_ticket(self, interaction):
        """Handle ticket claim button click"""
        guild = interaction.guild
        user = interaction.user
        channel = interaction.channel
        
        # Check if user is staff
        guild_config = self.db.get_guild_config(guild.id)
        is_staff = False

        
        
        if guild_config and guild_config.get('staff_role_id'):
            staff_role = guild.get_role(int(guild_config['staff_role_id']))
            if staff_role and staff_role in user.roles:
                is_staff = True
        
        # Also allow administrators
        if user.guild_permissions.administrator:
            is_staff = True
        
        if not is_staff:
            await interaction.response.send_message(
                "❌ Solo i membri dello staff possono claimare i ticket.",
                ephemeral=True
            )
            return
        
        # Check if ticket exists
        ticket = self.db.get_ticket(channel_id=channel.id)
        if not ticket:
            await interaction.response.send_message(
                "❌ Questo non è un canale ticket valido.",
                ephemeral=True
            )
            return
        
        # Check if ticket is already claimed
        claim_info = self.db.is_ticket_claimed(channel.id)
        if claim_info['claimed']:
            claimed_user = guild.get_member(int(claim_info['claimed_by']))
            claimed_name = claimed_user.display_name if claimed_user else "Utente sconosciuto"
            await interaction.response.send_message(
                f"❌ Questo ticket è già stato claimato da **{claimed_name}**.",
                ephemeral=True
            )
            return
        
        # Claim the ticket
        success = self.db.claim_ticket(channel.id, user.id)
        
        if success:
            # Update channel name to show claimed status
            try:
                new_name = f"🔒-{channel.name}" if not channel.name.startswith("🔒-") else channel.name
                await channel.edit(name=new_name)
            except:
                pass
            
            # Create claim embed
            embed = discord.Embed(
                title="📌 Ticket Claimato",
                description=f"**{user.mention}** ha preso in carico questo ticket.",
                color=self.config.get_embed_color('success')
            )
            embed.add_field(
                name="👤 Staff Assegnato", 
                value=user.mention, 
                inline=True
            )
            embed.add_field(
                name="📅 Data Claim", 
                value=f"<t:{int(datetime.now().timestamp())}:f>", 
                inline=True
            )
            embed.set_footer(text="Il ticket è ora gestito da questo membro dello staff")
            
            # Update buttons
            view = discord.ui.View(timeout=None)
            
            unclaim_button = discord.ui.Button(
                label="📌 Unclaim",
                emoji="📌",
                style=discord.ButtonStyle.secondary,
                custom_id=f"unclaim_ticket_{channel.id}"
            )
            
            close_button = discord.ui.Button(
                label="🔒 Chiudi Ticket",
                emoji="🔒",
                style=discord.ButtonStyle.danger,
                custom_id=f"close_ticket_{channel.id}"
            )
            
            view.add_item(unclaim_button)
            view.add_item(close_button)
            
            await interaction.response.send_message(embed=embed, view=view)
            
            # Log the claim
            await self.log_ticket_action(
                guild, 
                "Ticket Claimato", 
                f"{user.mention} ha claimato il ticket {channel.mention}"
            )
        else:
            await interaction.response.send_message(
                "❌ Errore durante il claim del ticket. Riprova più tardi.",
                ephemeral=True
            )
    
    async def handle_unclaim_ticket(self, interaction):
        """Handle ticket unclaim button click"""
        guild = interaction.guild
        user = interaction.user
        channel = interaction.channel
        
        # Check if ticket exists
        ticket = self.db.get_ticket(channel_id=channel.id)
        if not ticket:
            await interaction.response.send_message(
                "❌ Questo non è un canale ticket valido.",
                ephemeral=True
            )
            return
        
        # Check if ticket is claimed
        claim_info = self.db.is_ticket_claimed(channel.id)
        if not claim_info['claimed']:
            await interaction.response.send_message(
                "❌ Questo ticket non è attualmente claimato.",
                ephemeral=True
            )
            return
        
        # Check if user can unclaim (must be the one who claimed it or admin)
        can_unclaim = False
        if str(user.id) == claim_info['claimed_by']:
            can_unclaim = True
        elif user.guild_permissions.administrator:
            can_unclaim = True
        else:
            # Check if user is staff
            guild_config = self.db.get_guild_config(guild.id)
            if guild_config and guild_config.get('staff_role_id'):
                staff_role = guild.get_role(int(guild_config['staff_role_id']))
                if staff_role and staff_role in user.roles:
                    can_unclaim = True
        
        if not can_unclaim:
            await interaction.response.send_message(
                "❌ Puoi fare unclaim solo dei ticket che hai claimato tu.",
                ephemeral=True
            )
            return
        
        # Unclaim the ticket
        success = self.db.unclaim_ticket(channel.id)
        
        if success:
            # Update channel name to remove claimed status
            try:
                new_name = channel.name.replace("🔒-", "") if channel.name.startswith("🔒-") else channel.name
                await channel.edit(name=new_name)
            except:
                pass
            
            # Create unclaim embed
            embed = discord.Embed(
                title="📌 Ticket Unclaimato",
                description=f"**{user.mention}** ha rilasciato questo ticket.",
                color=self.config.get_embed_color('warning')
            )
            embed.add_field(
                name="📅 Data Unclaim", 
                value=f"<t:{int(datetime.now().timestamp())}:f>", 
                inline=True
            )
            embed.set_footer(text="Il ticket è ora disponibile per essere claimato da altri staff")
            
            # Update buttons back to claim
            view = discord.ui.View(timeout=None)
            
            claim_button = discord.ui.Button(
                label="📌 Claim",
                emoji="📌",
                style=discord.ButtonStyle.secondary,
                custom_id=f"claim_ticket_{channel.id}"
            )
            
            close_button = discord.ui.Button(
                label="🔒 Chiudi Ticket",
                emoji="🔒",
                style=discord.ButtonStyle.danger,
                custom_id=f"close_ticket_{channel.id}"
            )
            
            view.add_item(claim_button)
            view.add_item(close_button)
            
            await interaction.response.send_message(embed=embed, view=view)
            
            # Log the unclaim
            await self.log_ticket_action(
                guild, 
                "Ticket Unclaimato", 
                f"{user.mention} ha fatto unclaim del ticket {channel.mention}"
            )
        else:
            await interaction.response.send_message(
                "❌ Errore durante l'unclaim del ticket. Riprova più tardi.",
                ephemeral=True
            )
    
    async def show_ticket_form(self, interaction):
        """Show ticket form modal"""
        # Get ticket data to verify user permission
        ticket = self.db.get_ticket(channel_id=interaction.channel.id)
        if not ticket:
            await interaction.response.send_message(
                "❌ Questo non è un canale ticket valido.",
                ephemeral=True
            )
            return
        
        # Check if user is the ticket creator
        if str(interaction.user.id) != ticket['user_id']:
            await interaction.response.send_message(
                "❌ Solo il creatore del ticket può compilare il modulo.",
                ephemeral=True
            )
            return
        
        # Show the modal
        modal = TicketModal()
        await interaction.response.send_modal(modal)
    
    async def handle_ticket_form(self, interaction):
        """Handle ticket form submission"""
        minecraft_nick = interaction.data['components'][0]['components'][0]['value']
        reason = interaction.data['components'][1]['components'][0]['value']
        
        # Update database with form data
        success = self.db.update_ticket_form_data(
            interaction.channel.id,
            minecraft_nick,
            reason
        )
        
        if success:
            # Create summary embed
            embed = discord.Embed(
                title="📋 Informazioni Ticket",
                color=self.config.get_embed_color('info')
            )
            embed.add_field(name="🎮 Nick Minecraft", value=minecraft_nick, inline=True)
            embed.add_field(name="📝 Motivo", value=reason, inline=False)
            embed.add_field(name="👤 Creato da", value=interaction.user.mention, inline=True)
            embed.add_field(name="📅 Data", value=f"<t:{int(datetime.now().timestamp())}:F>", inline=True)
            embed.set_footer(text="Informazioni del ticket")
            
            await interaction.response.send_message(
                "✅ **Modulo compilato con successo!**\n\n"
                "Grazie per aver fornito le informazioni. Lo staff risponderà al più presto.",
                embed=embed
            )
            
            # Notify staff if configured
            await self.notify_staff_new_ticket(interaction.guild, interaction.channel, interaction.user)
        else:
            await interaction.response.send_message(
                "❌ Errore nel salvare le informazioni. Riprova più tardi.",
                ephemeral=True
            )
    
    async def notify_staff_new_ticket(self, guild, channel, user):
        """Notify staff about new ticket"""
        guild_config = self.db.get_guild_config(guild.id)
        
        if guild_config and guild_config.get('staff_role_id'):
            staff_role = guild.get_role(int(guild_config['staff_role_id']))
            if staff_role:
                embed = discord.Embed(
                    title="🔔 Nuovo Ticket",
                    description=f"Un nuovo ticket è stato aperto da {user.mention} in {channel.mention}",
                    color=self.config.get_embed_color('info')
                )
                await channel.send(f"{staff_role.mention}", embed=embed, delete_after=10)
    
    async def close_ticket_button(self, interaction):
        """Handle ticket closure from button"""
        channel = interaction.channel
        
        # Verify this is a ticket channel
        ticket = self.db.get_ticket(channel_id=channel.id)
        if not ticket:
            await interaction.response.send_message(
                "❌ Questo non è un canale ticket valido.",
                ephemeral=True
            )
            return
        
        # Check permissions
        if not await self.can_close_ticket(interaction.user, ticket):
            await interaction.response.send_message(
                self.config.get_message('no_permission'),
                ephemeral=True
            )
            return
        
        # Send confirmation
        embed = discord.Embed(
            title="⚠️ Conferma Chiusura",
            description=self.config.get_message('ticket_close_confirmation'),
            color=self.config.get_embed_color('warning')
        )
        
        view = discord.ui.View(timeout=60)
        confirm_btn = discord.ui.Button(label="✅ Conferma", style=discord.ButtonStyle.danger, custom_id="confirm_close")
        cancel_btn = discord.ui.Button(label="❌ Annulla", style=discord.ButtonStyle.secondary, custom_id="cancel_close")
        
        view.add_item(confirm_btn)
        view.add_item(cancel_btn)
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    async def confirm_close_ticket(self, interaction):
        """Confirm and close the ticket"""
        channel = interaction.channel
        
        # Close ticket in database
        success = self.db.close_ticket(channel.id, interaction.user.id)
        
        if success:
            # Send closing message
            embed = discord.Embed(
                title="🔒 Ticket Chiuso",
                description=f"Questo ticket è stato chiuso da {interaction.user.mention}.\n\n"
                           f"Il canale verrà eliminato tra 10 secondi.",
                color=self.config.get_embed_color('error')
            )
            
            await interaction.response.send_message(embed=embed)
            
            # Log closure
            await self.log_ticket_action(
                interaction.guild,
                "Ticket Chiuso",
                f"{interaction.user.mention} ha chiuso {channel.mention}"
            )
            
            # Delete channel after delay
            await asyncio.sleep(10)
            try:
                await channel.delete(reason=f"Ticket chiuso da {interaction.user}")
            except Exception as e:
                print(f"❌ Error deleting ticket channel: {e}")
        else:
            await interaction.response.send_message(
                "❌ Errore nella chiusura del ticket.",
                ephemeral=True
            )
    
    async def can_close_ticket(self, user, ticket):
        """Check if user can close the ticket"""
        # Ticket creator can always close their ticket
        if str(user.id) == ticket['user_id']:
            return True
        
        # Check if user has staff permissions
        guild_config = self.db.get_guild_config(ticket['guild_id'])
        if guild_config and guild_config.get('staff_role_id'):
            guild = self.bot.get_guild(int(ticket['guild_id']))
            if guild:
                staff_role = guild.get_role(int(guild_config['staff_role_id']))
                if staff_role and staff_role in user.roles:
                    return True
        
        # Check for admin permissions
        return user.guild_permissions.administrator
    
    async def rename_ticket(self, channel, new_name, user):
        """Rename a ticket channel"""
        ticket = self.db.get_ticket(channel_id=channel.id)
        if not ticket:
            return False, "❌ Questo non è un canale ticket valido."
        
        # Check permissions
        if not await self.can_close_ticket(user, ticket):
            return False, self.config.get_message('no_permission')
        
        try:
            old_name = channel.name
            await channel.edit(name=new_name, reason=f"Ticket rinominato da {user}")
            
            # Log action
            await self.log_ticket_action(
                channel.guild,
                "Ticket Rinominato",
                f"{user.mention} ha rinominato `{old_name}` in `{new_name}`"
            )
            
            return True, f"✅ Ticket rinominato da `{old_name}` a `{new_name}`"
        except Exception as e:
            print(f"❌ Error renaming ticket: {e}")
            return False, "❌ Errore nel rinomino del ticket."
    
    async def log_ticket_action(self, guild, action, description):
        """Log ticket actions to configured channel"""
        guild_config = self.db.get_guild_config(guild.id)
        
        if guild_config and guild_config.get('log_channel_id'):
            log_channel = guild.get_channel(int(guild_config['log_channel_id']))
            if log_channel:
                embed = discord.Embed(
                    title=f"📊 {action}",
                    description=description,
                    color=self.config.get_embed_color('info'),
                    timestamp=datetime.now()
                )
                embed.set_footer(text=f"Guild: {guild.name}")
                
                try:
                    await log_channel.send(embed=embed)
                except Exception as e:
                    print(f"❌ Error sending log message: {e}")
