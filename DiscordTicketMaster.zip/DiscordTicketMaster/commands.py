"""
Discord Bot Commands
Slash commands and traditional commands for ticket management
"""
import discord
from discord.ext import commands
from discord import app_commands

def setup_commands(bot):
    """Setup all bot commands"""
    
    @bot.tree.command(name="ticket", description="Crea un pannello per i ticket")
    @app_commands.describe(channel="Il canale dove creare il pannello (opzionale)")
    async def ticket_panel(interaction, channel: discord.TextChannel = None):
        """Create ticket panel command"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Hai bisogno dei permessi di amministratore per usare questo comando.",
                ephemeral=True
            )
            return
        
        target_channel = channel or interaction.channel
        success = await bot.ticket_system.create_ticket_panel(target_channel)
        
        if success:
            embed = discord.Embed(
                title="✅ Pannello Ticket Creato",
                description=f"Il pannello ticket è stato creato in {target_channel.mention}",
                color=bot.config.get_embed_color('primary')
            )
        else:
            embed = discord.Embed(
                title="❌ Errore",
                description="Errore nella creazione del pannello ticket.",
                color=bot.config.get_embed_color('error')
            )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="close", description="Chiudi il ticket corrente")
    async def close_ticket(interaction):
        """Close current ticket"""
        channel = interaction.channel
        
        # Verify this is a ticket channel
        ticket = bot.db.get_ticket(channel_id=channel.id)
        if not ticket:
            await interaction.response.send_message(
                "❌ Questo comando può essere utilizzato solo nei canali ticket.",
                ephemeral=True
            )
            return
        
        # Check permissions
        if not await bot.ticket_system.can_close_ticket(interaction.user, ticket):
            await interaction.response.send_message(
                bot.config.get_message('no_permission'),
                ephemeral=True
            )
            return
        
        # Close ticket
        success = bot.db.close_ticket(channel.id, interaction.user.id)
        
        if success:
            embed = discord.Embed(
                title="🔒 Ticket Chiuso",
                description=f"Questo ticket è stato chiuso da {interaction.user.mention}.\n\n"
                           f"Il canale verrà eliminato tra 10 secondi.",
                color=bot.config.get_embed_color('error')
            )
            
            await interaction.response.send_message(embed=embed)
            
            # Log and delete
            await bot.ticket_system.log_ticket_action(
                interaction.guild,
                "Ticket Chiuso",
                f"{interaction.user.mention} ha chiuso {channel.mention}"
            )
            
            import asyncio
            await asyncio.sleep(10)
            try:
                await channel.delete(reason=f"Ticket chiuso da {interaction.user}")
            except Exception as e:
                print(f"❌ Error deleting channel: {e}")
        else:
            await interaction.response.send_message(
                "❌ Errore nella chiusura del ticket.",
                ephemeral=True
            )
    
    @bot.tree.command(name="rename", description="Rinomina il ticket corrente")
    @app_commands.describe(name="Il nuovo nome per il ticket")
    async def rename_ticket(interaction, name: str):
        """Rename current ticket"""
        if len(name) < 1 or len(name) > 100:
            await interaction.response.send_message(
                "❌ Il nome deve essere tra 1 e 100 caratteri.",
                ephemeral=True
            )
            return
        
        # Clean name (Discord channel naming rules)
        clean_name = name.lower().replace(' ', '-').replace('_', '-')
        clean_name = ''.join(c for c in clean_name if c.isalnum() or c == '-')
        
        success, message = await bot.ticket_system.rename_ticket(
            interaction.channel,
            clean_name,
            interaction.user
        )
        
        color = bot.config.get_embed_color('primary') if success else bot.config.get_embed_color('error')
        embed = discord.Embed(description=message, color=color)
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="setup", description="Configura il sistema ticket per questo server")
    async def setup_ticket_system(interaction):
        """Setup ticket system for the guild"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Hai bisogno dei permessi di amministratore per usare questo comando.",
                ephemeral=True
            )
            return
        
        guild = interaction.guild
        
        # Get current configuration
        current_config = bot.db.get_guild_config(guild.id) or {}
        
        embed = discord.Embed(
            title="⚙️ Setup Sistema Ticket",
            description="Configurazione del sistema ticket per il server.",
            color=bot.config.get_embed_color('info')
        )
        
        # Category info
        category_id = current_config.get('ticket_category_id')
        if category_id:
            category = guild.get_channel(int(category_id))
            category_text = category.mention if category else "❌ Categoria non trovata"
        else:
            category_text = "❌ Non configurata"
        
        # Staff role info
        staff_role_id = current_config.get('staff_role_id')
        if staff_role_id:
            staff_role = guild.get_role(int(staff_role_id))
            staff_text = staff_role.mention if staff_role else "❌ Ruolo non trovato"
        else:
            staff_text = "❌ Non configurato"
        
        # Log channel info
        log_channel_id = current_config.get('log_channel_id')
        if log_channel_id:
            log_channel = guild.get_channel(int(log_channel_id))
            log_text = log_channel.mention if log_channel else "❌ Canale non trovato"
        else:
            log_text = "❌ Non configurato"
        
        embed.add_field(
            name="📁 Categoria Ticket",
            value=category_text,
            inline=False
        )
        embed.add_field(
            name="👥 Ruolo Staff",
            value=staff_text,
            inline=False
        )
        embed.add_field(
            name="📊 Canale Log",
            value=log_text,
            inline=False
        )
        
        # Statistics
        stats = bot.db.get_ticket_stats(guild.id)
        embed.add_field(
            name="📈 Statistiche",
            value=f"**Totali:** {stats['total']}\n"
                  f"**Aperti:** {stats['open']}\n"
                  f"**Chiusi:** {stats['closed']}",
            inline=True
        )
        
        embed.set_footer(text="Usa /setup-category, /setup-staff, /setup-logs per configurare")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="setup-category", description="Imposta la categoria per i ticket")
    @app_commands.describe(category="La categoria dove creare i ticket")
    async def setup_category(interaction, category: discord.CategoryChannel):
        """Setup ticket category"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Hai bisogno dei permessi di amministratore per usare questo comando.",
                ephemeral=True
            )
            return
        
        bot.db.update_guild_config(interaction.guild.id, ticket_category_id=str(category.id))
        
        embed = discord.Embed(
            title="✅ Categoria Configurata",
            description=f"I ticket verranno creati nella categoria {category.mention}",
            color=bot.config.get_embed_color('primary')
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="setup-staff", description="Imposta il ruolo staff per i ticket")
    @app_commands.describe(role="Il ruolo che può gestire i ticket")
    async def setup_staff(interaction, role: discord.Role):
        """Setup staff role"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Hai bisogno dei permessi di amministratore per usare questo comando.",
                ephemeral=True
            )
            return
        
        bot.db.update_guild_config(interaction.guild.id, staff_role_id=str(role.id))
        
        embed = discord.Embed(
            title="✅ Ruolo Staff Configurato",
            description=f"Il ruolo {role.mention} può ora gestire i ticket",
            color=bot.config.get_embed_color('primary')
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="setup-logs", description="Imposta il canale per i log dei ticket")
    @app_commands.describe(channel="Il canale dove inviare i log")
    async def setup_logs(interaction, channel: discord.TextChannel):
        """Setup log channel"""
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Hai bisogno dei permessi di amministratore per usare questo comando.",
                ephemeral=True
            )
            return
        
        bot.db.update_guild_config(interaction.guild.id, log_channel_id=str(channel.id))
        
        embed = discord.Embed(
            title="✅ Canale Log Configurato",
            description=f"I log dei ticket verranno inviati in {channel.mention}",
            color=bot.config.get_embed_color('primary')
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="stats", description="Mostra le statistiche dei ticket")
    async def ticket_stats(interaction):
        """Show ticket statistics"""
        stats = bot.db.get_ticket_stats(interaction.guild.id)
        
        embed = discord.Embed(
            title="📊 Statistiche Ticket",
            color=bot.config.get_embed_color('info')
        )
        
        embed.add_field(
            name="📈 Totali",
            value=f"**{stats['total']}** ticket totali",
            inline=True
        )
        embed.add_field(
            name="🟢 Aperti",
            value=f"**{stats['open']}** ticket aperti",
            inline=True
        )
        embed.add_field(
            name="🔴 Chiusi",
            value=f"**{stats['closed']}** ticket chiusi",
            inline=True
        )
        
        # Add user stats if not admin
        if not interaction.user.guild_permissions.administrator:
            user_tickets = bot.db.get_user_tickets(interaction.user.id, interaction.guild.id)
            embed.add_field(
                name="👤 I tuoi ticket",
                value=f"**{len(user_tickets)}** ticket aperti",
                inline=False
            )
        
        embed.set_footer(text=f"Server: {interaction.guild.name}")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="claim", description="Prendi in carico un ticket")
    async def claim_ticket(interaction):
        """Claim current ticket"""
        await bot.ticket_system.handle_claim_ticket(interaction)
    
    @bot.tree.command(name="unclaim", description="Rilascia un ticket claimato")
    async def unclaim_ticket(interaction):
        """Unclaim current ticket"""
        await bot.ticket_system.handle_unclaim_ticket(interaction)
    
    # Traditional prefix commands for backup
    @bot.command(name='ticket-panel')
    @commands.has_permissions(administrator=True)
    async def create_ticket_panel_prefix(ctx, channel: discord.TextChannel = None):
        """Create ticket panel with prefix command"""
        target_channel = channel or ctx.channel
        success = await bot.ticket_system.create_ticket_panel(target_channel)
        
        if success:
            await ctx.send(f"✅ Pannello ticket creato in {target_channel.mention}")
        else:
            await ctx.send("❌ Errore nella creazione del pannello ticket.")
