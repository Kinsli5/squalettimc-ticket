"""
Main entry point for the Discord Ticket Bot
Handles both Discord bot and web dashboard for 24/7 hosting
"""
import os
import threading
import asyncio
from bot import TicketBot
from web_dashboard import app
from keep_alive import keep_alive, auto_ping
from auto_restart import AutoRestart
from simple_uptime import start_uptime_service
from premium_monitor import start_premium_mode
from checkpoint_system import start_checkpoint_system

def run_web_server():
    """Run the web dashboard on port 5000"""
    app.run(host='0.0.0.0', port=5000, debug=False)

def run_discord_bot():
    """Run the Discord bot"""
    bot = TicketBot()
    # Get Discord token from environment with fallback
    token = os.getenv('DISCORD_TOKEN', 'your_discord_token_here')
    
    if token == 'your_discord_token_here':
        print("⚠️ WARNING: Using default Discord token. Please set DISCORD_TOKEN environment variable.")
    
    try:
        bot.run(token)
    except Exception as e:
        print(f"❌ Error starting Discord bot: {e}")

if __name__ == "__main__":
    print("🚀 Starting Discord Ticket Bot with PREMIUM 24/7 hosting...")
    print("💎 REPLIT CORE SIMULATION MODE - Hosting gratuito potenziato!")
    
    # Start enhanced auto-restart monitor
    auto_restart = AutoRestart()
    auto_restart.start()
    
    # Start premium monitoring system
    premium_monitor = start_premium_mode()
    
    # Start advanced checkpoint system
    checkpoint_system = start_checkpoint_system()
    
    # Start premium keep-alive system
    from keep_alive import auto_ping
    auto_ping()
    
    # Start uptime service on port 3000 for UptimeRobot monitoring
    start_uptime_service()
    
    # Start web dashboard in a separate thread
    web_thread = threading.Thread(target=run_web_server, daemon=True)
    web_thread.start()
    print("🌐 Web dashboard started on port 5000")
    
    # Additional monitoring thread for premium-like experience
    def premium_monitor():
        while True:
            try:
                time.sleep(300)  # Check every 5 minutes
                print(f"💎 PREMIUM MODE: All systems operational - {time.strftime('%H:%M:%S')}")
            except:
                pass
    
    monitor_thread = threading.Thread(target=premium_monitor, daemon=True)
    monitor_thread.start()
    
    # Start Discord bot in main thread
    print("🤖 Starting Discord bot with PREMIUM protection...")
    try:
        run_discord_bot()
    except Exception as e:
        print(f"❌ Bot crashed: {e}")
        print("🔄 Premium auto-restart will handle this...")