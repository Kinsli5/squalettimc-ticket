# Discord Ticket Bot System

## Overview

This is a comprehensive Discord ticket management bot built with Python that provides 24/7 hosting capabilities on Replit. The system allows Discord servers to manage support tickets through an intuitive interface with automated workflows, user forms, and administrative controls.

## System Architecture

### Backend Architecture
- **Python Discord Bot**: Built using discord.py library for Discord API interaction
- **SQLite Database**: Local database for ticket persistence and guild configurations
- **Flask Web Server**: Multi-threaded web dashboard for monitoring and management
- **Auto-Restart System**: Continuous monitoring and automatic recovery mechanisms

### Frontend Architecture
- **Web Dashboard**: Bootstrap-based responsive interface for ticket management
- **Discord UI Components**: Custom modals, buttons, and embeds for user interaction
- **Real-time Monitoring**: Health check endpoints and uptime tracking

### Hosting Strategy
- **Multi-port Configuration**: Different services on ports 3000, 5000, 8000, 8080
- **Keep-Alive System**: Prevents Replit from sleeping the application
- **UptimeRobot Integration**: External monitoring for 24/7 availability

## Key Components

### Ticket Management System (`ticket_system.py`)
- **Ticket Creation**: Modal-based form collection with user information
- **Ticket Panels**: Interactive Discord embed with creation buttons
- **Channel Management**: Automatic ticket channel creation and organization
- **Status Tracking**: Open, closed, and claimed ticket states

### Database Layer (`database.py`)
- **Ticket Storage**: Complete ticket lifecycle data persistence
- **Guild Configurations**: Per-server settings and customizations
- **User Management**: Ticket limits and user association tracking
- **Auto-migration**: Database schema updates with backward compatibility

### Configuration System (`config.py` + `config.json`)
- **JSON-based Settings**: Centralized configuration management
- **Runtime Modifications**: Dynamic configuration updates
- **Default Fallbacks**: Robust handling of missing configuration values
- **Feature Toggles**: Enable/disable system features per guild

### Web Dashboard (`web_dashboard.py`)
- **Statistics API**: Real-time ticket and guild metrics
- **Management Interface**: Web-based ticket administration
- **Health Monitoring**: System status and performance tracking
- **Configuration Panel**: Web-based settings management

## Data Flow

1. **Ticket Creation Flow**:
   - User clicks ticket button in Discord
   - Modal form appears requesting information
   - System validates and creates ticket channel
   - Database records ticket with user association
   - Staff notifications and channel permissions applied

2. **Ticket Management Flow**:
   - Staff can claim, close, or transfer tickets
   - All actions logged to database with timestamps
   - Channel permissions updated based on ticket status
   - Automatic cleanup for closed tickets after retention period

3. **Monitoring Flow**:
   - Health checks every 60 seconds via auto_restart.py
   - Multiple web endpoints for external monitoring
   - Automatic restart on failure detection
   - Logging all restart events to restart.log

## External Dependencies

### Core Libraries
- **discord.py**: Discord API interaction and bot functionality
- **flask**: Web server for dashboard and health endpoints
- **aiohttp**: Async HTTP client for Discord API communication
- **requests**: HTTP client for health checks and external monitoring

### System Dependencies
- **SQLite3**: Database engine (built into Python)
- **Threading**: Multi-threaded execution for bot and web server
- **Asyncio**: Asynchronous programming for Discord operations

### External Services
- **Discord API**: Primary platform integration
- **UptimeRobot**: External monitoring service (optional)
- **Replit Hosting**: Cloud hosting platform with auto-sleep prevention

## Deployment Strategy

### Replit Configuration
- **Python 3.11 Runtime**: Specified in .replit configuration
- **Auto-restart Protection**: Continuous monitoring prevents downtime
- **Multi-port Exposure**: Different services accessible on various ports
- **Environment Variables**: Discord token and sensitive data management

### Production Readiness
- **Error Handling**: Comprehensive exception catching and logging
- **Graceful Degradation**: System continues operating with reduced functionality on errors
- **Data Persistence**: SQLite database survives restarts and crashes
- **Health Monitoring**: Multiple endpoints for external monitoring services

### Scalability Considerations
- **Stateless Design**: No in-memory state dependency for critical operations
- **Database Optimization**: Efficient queries and automatic cleanup
- **Resource Management**: Controlled thread usage and memory footprint
- **Rate Limiting**: Discord API rate limit compliance built-in

## Changelog
- June 26, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.