
"""
Sistema di Auto-Restart per Hosting Gratuito 24/7
Garantisce che il bot rimanga sempre online
"""
import os
import sys
import time
import subprocess
import threading
from datetime import datetime

class AutoRestart:
    def __init__(self):
        self.restart_count = 0
        self.max_restarts = 50
        self.restart_delay = 120
        
    def monitor_process(self):
        """Monitora il processo principale e riavvia se necessario - PREMIUM MODE"""
        while True:
            try:
                time.sleep(180)  # Controlla ogni 3 minuti (più aggressivo)
                
                # Verifica se il processo sta rispondendo
                import requests
                try:
                    response = requests.get('http://127.0.0.1:8000/ping', timeout=15)
                    if response.status_code == 200:
                        print(f"✅ Process health check OK - {datetime.now().strftime('%H:%M:%S')}")
                        continue
                except:
                    # Aspetta 2 minuti prima di considerare offline
                    time.sleep(120)
                    try:
                        response = requests.get('http://127.0.0.1:8000/ping', timeout=15)
                        if response.status_code == 200:
                            print(f"✅ Process recovered - {datetime.now().strftime('%H:%M:%S')}")
                            continue
                    except:
                        pass
                
                # Se arriviamo qui, il processo non risponde davvero
                print(f"⚠️ Process genuinely not responding, preparing restart...")
                self.restart_bot()
                
            except Exception as e:
                print(f"❌ Monitor error: {e}")
                time.sleep(30)
    
    def restart_bot(self):
        """Riavvia il bot se necessario"""
        if self.restart_count >= self.max_restarts:
            print(f"🛑 Max restarts reached ({self.max_restarts}), stopping monitor")
            return
        
        self.restart_count += 1
        print(f"🔄 Auto-restart #{self.restart_count} at {datetime.now().strftime('%H:%M:%S')}")
        
        try:
            # Log del restart
            with open('restart.log', 'a') as f:
                f.write(f"{datetime.now().isoformat()}: Auto-restart #{self.restart_count}\n")
            
            # Aspetta prima del restart
            time.sleep(self.restart_delay)
            
            # Riavvia il processo principale
            print("🚀 Restarting main process...")
            os.execv(sys.executable, ['python'] + sys.argv)
            
        except Exception as e:
            print(f"❌ Restart failed: {e}")
    
    def start(self):
        """Avvia il sistema di monitoraggio"""
        print("🔍 Starting auto-restart monitor...")
        monitor_thread = threading.Thread(target=self.monitor_process, daemon=True)
        monitor_thread.start()

if __name__ == "__main__":
    auto_restart = AutoRestart()
    auto_restart.start()
    
    # Tieni il thread principale attivo
    try:
        while True:
            time.sleep(3600)  # Sleep per 1 ora
            print(f"🔄 Auto-restart system active - {datetime.now().strftime('%H:%M:%S')}")
    except KeyboardInterrupt:
        print("\n🛑 Auto-restart monitor stopped")
