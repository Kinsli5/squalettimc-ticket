from keep_alive import keep_alive
keep_alive()
"""
Main Discord Bot Class with ticket system integration
"""
import discord
from discord.ext import commands
import asyncio
import json
from database import Database
from config import Config
from ticket_system import TicketSystem
from commands import setup_commands
from modals import TicketModal

class TicketBot(commands.Bot):
    def __init__(self):
        # Bot configuration
        intents = discord.Intents.default()
        intents.guilds = True
        # Remove privileged intents that require explicit enabling
        # intents.message_content = True  # Privileged intent
        # intents.members = True  # Privileged intent
        
        # Initialize config first
        self.config = Config()
        
        super().__init__(
            command_prefix=self.config.get_prefix(),
            intents=intents,
            help_command=None
        )
        
        # Initialize components
        self.db = Database()
        self.ticket_system = TicketSystem(self)
        
        # Setup event handlers
        self.setup_events()
        
        # Add commands
        setup_commands(self)
    
    def setup_events(self):
        """Setup bot event handlers"""
        
        @self.event
        async def on_ready():
            print(f"✅ {self.user} is now online!")
            print(f"📊 Connected to {len(self.guilds)} servers")
            
            # Sync slash commands
            try:
                synced = await self.tree.sync()
                print(f"🔄 Synced {len(synced)} command(s)")
            except Exception as e:
                print(f"❌ Failed to sync commands: {e}")
            
            # Set bot status
            await self.change_presence(
                activity=discord.Activity(
                    type=discord.ActivityType.playing,
                    name="SqualettiMC"
                )
            )
        
        @self.event
        async def on_interaction(interaction):
            """Handle button clicks and modal submissions"""
            if interaction.type == discord.InteractionType.component:
                await self.handle_button_interaction(interaction)
            elif interaction.type == discord.InteractionType.modal_submit:
                await self.handle_modal_interaction(interaction)
    
    async def handle_button_interaction(self, interaction):
        """Handle button click interactions"""
        custom_id = interaction.data.get('custom_id', '')
        
        if custom_id == 'create_ticket':
            await self.ticket_system.create_ticket_button(interaction)
        elif custom_id == 'fill_form':
            await self.ticket_system.show_ticket_form(interaction)
        elif custom_id.startswith('close_ticket_'):
            await self.ticket_system.close_ticket_button(interaction)
        elif custom_id.startswith('claim_ticket_'):
            await self.ticket_system.handle_claim_ticket(interaction)
        elif custom_id.startswith('unclaim_ticket_'):
            await self.ticket_system.handle_unclaim_ticket(interaction)
        elif custom_id == 'confirm_close':
            await self.ticket_system.confirm_close_ticket(interaction)
        elif custom_id == 'cancel_close':
            await interaction.response.send_message("❌ Chiusura ticket annullata.", ephemeral=True)
    
    async def handle_modal_interaction(self, interaction):
        """Handle modal form submissions"""
        if interaction.data.get('custom_id') == 'ticket_form':
            await self.ticket_system.handle_ticket_form(interaction)
            if __name__ == "__main__":
                bot = TicketBot()
                bot.run(bot.config.get_token())
                