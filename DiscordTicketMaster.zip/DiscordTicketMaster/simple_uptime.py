"""
Simple uptime endpoint using Flask on port 3000
This will be publicly accessible via Replit's domain
"""
from flask import Flask, jsonify
import time
import threading

app = Flask(__name__)

@app.route('/')
def uptime_check():
    return jsonify({
        'status': 'online',
        'service': 'discord-ticket-bot',
        'timestamp': int(time.time()),
        'message': 'Bot is running'
    })

@app.route('/health')
def health():
    return "OK"

@app.route('/ping')
def ping():
    return "pong"

def run_uptime_service():
    """Run the uptime service on port 3000"""
    app.run(host='0.0.0.0', port=3000, debug=False)

def start_uptime_service():
    """Start uptime service in background thread"""
    thread = threading.Thread(target=run_uptime_service, daemon=True)
    thread.start()
    print("🔗 Uptime service started on port 3000")
    return thread