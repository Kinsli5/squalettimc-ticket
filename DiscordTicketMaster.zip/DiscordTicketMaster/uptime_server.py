"""
Simple HTTP server for uptime monitoring
Runs on port 8080 for external access
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import threading
import time

class UptimeHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        """Handle GET requests"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        
        response = {
            'status': 'online',
            'service': 'discord-ticket-bot',
            'timestamp': time.time(),
            'uptime': 'running'
        }
        
        self.wfile.write(json.dumps(response).encode())
    
    def do_HEAD(self):
        """Handle HEAD requests"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
    
    def log_message(self, format, *args):
        """Suppress log messages"""
        pass

def start_uptime_server():
    """Start the uptime monitoring server"""
    server = HTTPServer(('0.0.0.0', 8080), UptimeHandler)
    print("🌐 Uptime server started on port 8080")
    server.serve_forever()

def run_uptime_server():
    """Run uptime server in background thread"""
    thread = threading.Thread(target=start_uptime_server, daemon=True)
    thread.start()
    return thread