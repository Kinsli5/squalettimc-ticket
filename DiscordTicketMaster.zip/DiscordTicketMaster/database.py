"""
Database management for ticket system using SQLite
"""
import sqlite3
import json
from datetime import datetime
import os

class Database:
    def __init__(self, db_path='tickets.db'):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database tables"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Tickets table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tickets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ticket_id TEXT UNIQUE NOT NULL,
                    user_id TEXT NOT NULL,
                    channel_id TEXT NOT NULL,
                    guild_id TEXT NOT NULL,
                    minecraft_nick TEXT,
                    reason TEXT,
                    status TEXT DEFAULT 'open',
                    claimed_by TEXT,
                    claimed_at TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    closed_at TIMESTAMP,
                    closed_by TEXT
                )
            ''')
            
            # Add columns to existing tickets table if they don't exist
            try:
                cursor.execute('ALTER TABLE tickets ADD COLUMN claimed_by TEXT')
            except sqlite3.OperationalError:
                pass  # Column already exists
            
            try:
                cursor.execute('ALTER TABLE tickets ADD COLUMN claimed_at TIMESTAMP')
            except sqlite3.OperationalError:
                pass  # Column already exists
            
            # Guild configurations table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS guild_configs (
                    guild_id TEXT PRIMARY KEY,
                    ticket_category_id TEXT,
                    staff_role_id TEXT,
                    log_channel_id TEXT,
                    ticket_counter INTEGER DEFAULT 0,
                    config_data TEXT
                )
            ''')
            
            conn.commit()
            print("✅ Database initialized successfully")
    
    def create_ticket(self, ticket_id, user_id, channel_id, guild_id, minecraft_nick=None, reason=None):
        """Create a new ticket record"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute('''
                    INSERT INTO tickets (ticket_id, user_id, channel_id, guild_id, minecraft_nick, reason)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (ticket_id, user_id, channel_id, guild_id, minecraft_nick, reason))
                conn.commit()
                return True
            except sqlite3.IntegrityError:
                return False
    
    def get_ticket(self, ticket_id=None, channel_id=None):
        """Get ticket by ID or channel ID"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if ticket_id:
                cursor.execute('SELECT * FROM tickets WHERE ticket_id = ?', (ticket_id,))
            elif channel_id:
                cursor.execute('SELECT * FROM tickets WHERE channel_id = ?', (str(channel_id),))
            else:
                return None
            
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def update_ticket_form_data(self, channel_id, minecraft_nick, reason):
        """Update ticket with form data"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE tickets 
                SET minecraft_nick = ?, reason = ?
                WHERE channel_id = ?
            ''', (minecraft_nick, reason, str(channel_id)))
            conn.commit()
            return cursor.rowcount > 0
    
    def close_ticket(self, channel_id, closed_by):
        """Close a ticket"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE tickets 
                SET status = 'closed', closed_at = CURRENT_TIMESTAMP, closed_by = ?
                WHERE channel_id = ?
            ''', (str(closed_by), str(channel_id)))
            conn.commit()
            return cursor.rowcount > 0
    
    def add_ticket_note(self, channel_id, note, user_id):
        """Add a note to a ticket"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            # For now, we'll store notes in a simple way
            # In a more complex system, you might want a separate notes table
            cursor.execute('''
                UPDATE tickets 
                SET reason = COALESCE(reason, '') || CHAR(10) || 'Nota: ' || ?
                WHERE channel_id = ?
            ''', (note, str(channel_id)))
            conn.commit()
            return cursor.rowcount > 0
    
    def get_guild_config(self, guild_id):
        """Get guild configuration"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM guild_configs WHERE guild_id = ?', (str(guild_id),))
            row = cursor.fetchone()
            
            if row:
                config = dict(row)
                if config['config_data']:
                    config['config_data'] = json.loads(config['config_data'])
                return config
            return None
    
    def update_guild_config(self, guild_id, **kwargs):
        """Update guild configuration"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Check if config exists
            existing = self.get_guild_config(guild_id)
            
            if existing:
                # Update existing config
                set_clauses = []
                values = []
                for key, value in kwargs.items():
                    if key == 'config_data' and isinstance(value, dict):
                        value = json.dumps(value)
                    set_clauses.append(f"{key} = ?")
                    values.append(value)
                
                if set_clauses:
                    values.append(str(guild_id))
                    query = f"UPDATE guild_configs SET {', '.join(set_clauses)} WHERE guild_id = ?"
                    cursor.execute(query, values)
            else:
                # Insert new config
                cursor.execute('''
                    INSERT INTO guild_configs (guild_id, ticket_category_id, staff_role_id, log_channel_id, ticket_counter)
                    VALUES (?, ?, ?, ?, ?)
                ''', (str(guild_id), 
                      kwargs.get('ticket_category_id'),
                      kwargs.get('staff_role_id'),
                      kwargs.get('log_channel_id'),
                      kwargs.get('ticket_counter', 0)))
            
            conn.commit()
    
    def increment_ticket_counter(self, guild_id):
        """Increment and return the next ticket counter"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Get current counter
            cursor.execute('SELECT ticket_counter FROM guild_configs WHERE guild_id = ?', (str(guild_id),))
            result = cursor.fetchone()
            
            if result:
                new_counter = result[0] + 1
                cursor.execute('UPDATE guild_configs SET ticket_counter = ? WHERE guild_id = ?', 
                             (new_counter, str(guild_id)))
            else:
                new_counter = 1
                cursor.execute('''
                    INSERT INTO guild_configs (guild_id, ticket_counter)
                    VALUES (?, ?)
                ''', (str(guild_id), new_counter))
            
            conn.commit()
            return new_counter
    
    def get_user_tickets(self, user_id, guild_id, status='open'):
        """Get user's tickets"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM tickets 
                WHERE user_id = ? AND guild_id = ? AND status = ?
                ORDER BY created_at DESC
            ''', (str(user_id), str(guild_id), status))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_ticket_stats(self, guild_id):
        """Get ticket statistics for a guild"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Total tickets
            cursor.execute('SELECT COUNT(*) FROM tickets WHERE guild_id = ?', (str(guild_id),))
            total_tickets = cursor.fetchone()[0]
            
            # Open tickets
            cursor.execute('SELECT COUNT(*) FROM tickets WHERE guild_id = ? AND status = "open"', (str(guild_id),))
            open_tickets = cursor.fetchone()[0]
            
            # Closed tickets
            cursor.execute('SELECT COUNT(*) FROM tickets WHERE guild_id = ? AND status = "closed"', (str(guild_id),))
            closed_tickets = cursor.fetchone()[0]
            
            # Claimed tickets
            cursor.execute('SELECT COUNT(*) FROM tickets WHERE guild_id = ? AND claimed_by IS NOT NULL AND status = "open"', (str(guild_id),))
            claimed_tickets = cursor.fetchone()[0]
            
            return {
                'total': total_tickets,
                'open': open_tickets,
                'closed': closed_tickets,
                'claimed': claimed_tickets
            }
    
    def claim_ticket(self, channel_id, staff_user_id):
        """Claim a ticket by staff member"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute('''
                    UPDATE tickets 
                    SET claimed_by = ?, claimed_at = CURRENT_TIMESTAMP 
                    WHERE channel_id = ? AND status = "open"
                ''', (str(staff_user_id), str(channel_id)))
                conn.commit()
                return cursor.rowcount > 0
            except Exception as e:
                print(f"❌ Error claiming ticket: {e}")
                return False
    
    def unclaim_ticket(self, channel_id):
        """Unclaim a ticket"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute('''
                    UPDATE tickets 
                    SET claimed_by = NULL, claimed_at = NULL 
                    WHERE channel_id = ? AND status = "open"
                ''', (str(channel_id),))
                conn.commit()
                return cursor.rowcount > 0
            except Exception as e:
                print(f"❌ Error unclaiming ticket: {e}")
                return False
    
    def is_ticket_claimed(self, channel_id):
        """Check if ticket is claimed and by whom"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute('SELECT claimed_by, claimed_at FROM tickets WHERE channel_id = ?', (str(channel_id),))
            result = cursor.fetchone()
            if result and result['claimed_by']:
                return {
                    'claimed': True,
                    'claimed_by': result['claimed_by'],
                    'claimed_at': result['claimed_at']
                }
            return {'claimed': False}
