"""
Web Dashboard for Discord Bot Management
Provides a web interface for monitoring and configuration
"""
from flask import Flask, render_template, jsonify, request, redirect, url_for
import os
import json
from datetime import datetime
from database import Database
from config import Config

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'discord_ticket_bot_secret_key')

# Initialize components
db = Database()
config = Config()

@app.route('/')
def dashboard():
    """Main dashboard page"""
    # Get basic statistics
    total_guilds = len(get_guild_stats())
    total_tickets = get_total_tickets()
    active_tickets = get_active_tickets()

    stats = {
        'total_guilds': total_guilds,
        'total_tickets': total_tickets,
        'active_tickets': active_tickets,
        'closed_tickets': total_tickets - active_tickets
    }

    return render_template('dashboard.html', stats=stats)

@app.route('/api/stats')
def api_stats():
    """API endpoint for statistics"""
    guild_stats = get_guild_stats()

    return jsonify({
        'guilds': len(guild_stats),
        'total_tickets': get_total_tickets(),
        'active_tickets': get_active_tickets(),
        'guild_breakdown': guild_stats
    })

@app.route('/api/tickets')
def api_tickets():
    """API endpoint for ticket data"""
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)

    tickets = get_recent_tickets(limit, offset)

    return jsonify({
        'tickets': tickets,
        'total': get_total_tickets()
    })

@app.route('/api/config', methods=['GET', 'POST'])
def api_config():
    """API endpoint for configuration management"""
    if request.method == 'GET':
        return jsonify(config.config)

    elif request.method == 'POST':
        try:
            updates = request.json
            success = config.update_config(updates)

            return jsonify({
                'success': success,
                'message': 'Configuration updated successfully' if success else 'Failed to update configuration'
            })
        except Exception as e:
            return jsonify({
                'success': False,
                'message': f'Error updating configuration: {str(e)}'
            }), 400

@app.route('/api/health')
def api_health():
    """API health check"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'database': check_database_health(),
        'config': config.validate_config()
    })

@app.route('/api/checkpoints')
def api_checkpoints():
    """API per lista checkpoint"""
    try:
        from checkpoint_system import checkpoint_system
        checkpoints = checkpoint_system.list_checkpoints()
        return jsonify({
            'status': 'success',
            'checkpoints': checkpoints,
            'total': len(checkpoints)
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/checkpoints/create', methods=['POST'])
def api_create_checkpoint():
    """API per creare checkpoint manuale"""
    try:
        from checkpoint_system import checkpoint_system
        checkpoint_name = checkpoint_system.create_checkpoint()
        if checkpoint_name:
            return jsonify({
                'status': 'success',
                'checkpoint_name': checkpoint_name,
                'message': 'Checkpoint creato con successo'
            })
        else:
            return jsonify({
                'status': 'error',
                'message': 'Fallimento creazione checkpoint'
            }), 500
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/checkpoints/<checkpoint_name>')
def api_checkpoint_info(checkpoint_name):
    """API per informazioni checkpoint"""
    try:
        from checkpoint_system import checkpoint_system
        info = checkpoint_system.get_checkpoint_info(checkpoint_name)
        if info:
            return jsonify({
                'status': 'success',
                'checkpoint': info
            })
        else:
            return jsonify({
                'status': 'error',
                'message': 'Checkpoint non trovato'
            }), 404
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/keep-alive')
def keep_alive():
    """Keep alive endpoint for Replit hosting"""
    return jsonify({
        'status': 'alive',
        'timestamp': datetime.now().isoformat(),
        'message': 'Discord Ticket Bot is running 24/7'
    })

@app.route('/')
def root():
    """Root endpoint for UptimeRobot monitoring"""
    return jsonify({
        'status': 'online',
        'service': 'discord-ticket-bot',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return "OK", 200

@app.route('/ping')
def ping():
    """Simple ping endpoint"""
    return "pong"

# Helper functions
def get_guild_stats():
    """Get statistics for all guilds"""
    try:
        import sqlite3
        with sqlite3.connect(db.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute('''
                SELECT guild_id, COUNT(*) as ticket_count,
                       SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_tickets,
                       SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_tickets
                FROM tickets 
                GROUP BY guild_id
            ''')

            results = cursor.fetchall()
            return [dict(row) for row in results]
    except Exception as e:
        print(f"❌ Error getting guild stats: {e}")
        return []

def get_total_tickets():
    """Get total number of tickets"""
    try:
        import sqlite3
        with sqlite3.connect(db.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM tickets')
            return cursor.fetchone()[0]
    except Exception:
        return 0

def get_active_tickets():
    """Get number of active tickets"""
    try:
        import sqlite3
        with sqlite3.connect(db.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM tickets WHERE status = "open"')
            return cursor.fetchone()[0]
    except Exception:
        return 0

def get_recent_tickets(limit=50, offset=0):
    """Get recent tickets with pagination"""
    try:
        import sqlite3
        with sqlite3.connect(db.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute('''
                SELECT ticket_id, user_id, guild_id, minecraft_nick, reason, status,
                       created_at, closed_at, closed_by
                FROM tickets 
                ORDER BY created_at DESC 
                LIMIT ? OFFSET ?
            ''', (limit, offset))

            results = cursor.fetchall()
            return [dict(row) for row in results]
    except Exception as e:
        print(f"❌ Error getting recent tickets: {e}")
        return []

def check_database_health():
    """Check if database is accessible"""
    try:
        import sqlite3
        with sqlite3.connect(db.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT 1')
            return True
    except Exception:
        return False

if __name__ == '__main__':
    print("🌐 Starting web dashboard...")
    app.run(host='0.0.0.0', port=5000, debug=False)