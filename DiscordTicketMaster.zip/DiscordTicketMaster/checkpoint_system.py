
"""
Sistema di Checkpoint Avanzato per Discord Ticket Bot
Salva e ripristina lo stato del bot con backup multipli
"""
import json
import time
import threading
import sqlite3
import os
from datetime import datetime, timedelta
import shutil

class CheckpointSystem:
    def __init__(self, db_path="tickets.db"):
        self.db_path = db_path
        self.checkpoint_dir = "checkpoints"
        self.max_checkpoints = 20
        self.checkpoint_interval = 300  # 5 minuti
        self.running = False
        
        # Crea directory checkpoint
        os.makedirs(self.checkpoint_dir, exist_ok=True)
        
    def start_checkpoint_system(self):
        """Avvia il sistema di checkpoint automatico"""
        self.running = True
        checkpoint_thread = threading.Thread(target=self._checkpoint_loop, daemon=True)
        checkpoint_thread.start()
        print("💾 CHECKPOINT SYSTEM: Avviato sistema backup automatico")
        
    def stop_checkpoint_system(self):
        """Ferma il sistema di checkpoint"""
        self.running = False
        print("🛑 CHECKPOINT SYSTEM: Sistema backup fermato")
        
    def _checkpoint_loop(self):
        """Loop principale per checkpoint automatici"""
        while self.running:
            try:
                self.create_checkpoint()
                self.cleanup_old_checkpoints()
                time.sleep(self.checkpoint_interval)
            except Exception as e:
                print(f"❌ CHECKPOINT ERROR: {e}")
                time.sleep(60)
                
    def create_checkpoint(self):
        """Crea un nuovo checkpoint completo"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        checkpoint_name = f"checkpoint_{timestamp}"
        checkpoint_path = os.path.join(self.checkpoint_dir, checkpoint_name)
        
        try:
            os.makedirs(checkpoint_path, exist_ok=True)
            
            # 1. Backup database
            if os.path.exists(self.db_path):
                shutil.copy2(self.db_path, os.path.join(checkpoint_path, "tickets.db"))
            
            # 2. Backup configurazioni
            config_files = ["config.json", ".replit", "restart.log"]
            for config_file in config_files:
                if os.path.exists(config_file):
                    shutil.copy2(config_file, checkpoint_path)
            
            # 3. Salva stato sistema
            system_state = self._get_system_state()
            with open(os.path.join(checkpoint_path, "system_state.json"), 'w') as f:
                json.dump(system_state, f, indent=2)
            
            # 4. Salva statistiche bot
            bot_stats = self._get_bot_statistics()
            with open(os.path.join(checkpoint_path, "bot_stats.json"), 'w') as f:
                json.dump(bot_stats, f, indent=2)
                
            # 5. Crea manifesto checkpoint
            manifest = {
                "timestamp": timestamp,
                "checkpoint_name": checkpoint_name,
                "created_at": datetime.now().isoformat(),
                "system_state": system_state,
                "files_backed_up": len(os.listdir(checkpoint_path))
            }
            
            with open(os.path.join(checkpoint_path, "manifest.json"), 'w') as f:
                json.dump(manifest, f, indent=2)
                
            print(f"💾 CHECKPOINT CREATED: {checkpoint_name} ({manifest['files_backed_up']} files)")
            return checkpoint_name
            
        except Exception as e:
            print(f"❌ CHECKPOINT FAILED: {e}")
            return None
            
    def _get_system_state(self):
        """Ottiene stato attuale del sistema"""
        try:
            import psutil
            
            return {
                "uptime_seconds": time.time(),
                "memory_usage": psutil.virtual_memory().percent,
                "cpu_usage": psutil.cpu_percent(),
                "disk_usage": psutil.disk_usage('.').percent,
                "active_threads": threading.active_count(),
                "timestamp": datetime.now().isoformat()
            }
        except ImportError:
            return {
                "uptime_seconds": time.time(),
                "active_threads": threading.active_count(),
                "timestamp": datetime.now().isoformat()
            }
            
    def _get_bot_statistics(self):
        """Ottiene statistiche del bot dal database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                # Statistiche generali
                cursor.execute("SELECT COUNT(*) as total FROM tickets")
                total_tickets = cursor.fetchone()['total']
                
                cursor.execute("SELECT COUNT(*) as open FROM tickets WHERE status = 'open'")
                open_tickets = cursor.fetchone()['open']
                
                cursor.execute("SELECT COUNT(*) as closed FROM tickets WHERE status = 'closed'")
                closed_tickets = cursor.fetchone()['closed']
                
                # Statistiche per guild
                cursor.execute("""
                    SELECT guild_id, COUNT(*) as count 
                    FROM tickets 
                    GROUP BY guild_id 
                    ORDER BY count DESC
                """)
                guild_stats = [dict(row) for row in cursor.fetchall()]
                
                return {
                    "total_tickets": total_tickets,
                    "open_tickets": open_tickets,
                    "closed_tickets": closed_tickets,
                    "guild_statistics": guild_stats,
                    "last_updated": datetime.now().isoformat()
                }
                
        except Exception as e:
            print(f"❌ Error getting bot stats: {e}")
            return {"error": str(e)}
            
    def cleanup_old_checkpoints(self):
        """Rimuove checkpoint vecchi mantenendo solo i più recenti"""
        try:
            checkpoints = []
            for item in os.listdir(self.checkpoint_dir):
                item_path = os.path.join(self.checkpoint_dir, item)
                if os.path.isdir(item_path) and item.startswith("checkpoint_"):
                    checkpoints.append((item, os.path.getctime(item_path)))
            
            # Ordina per data di creazione (più recenti prima)
            checkpoints.sort(key=lambda x: x[1], reverse=True)
            
            # Rimuovi checkpoint in eccesso
            for checkpoint_name, _ in checkpoints[self.max_checkpoints:]:
                checkpoint_path = os.path.join(self.checkpoint_dir, checkpoint_name)
                shutil.rmtree(checkpoint_path)
                print(f"🗑️ CHECKPOINT CLEANED: Rimosso {checkpoint_name}")
                
        except Exception as e:
            print(f"❌ CHECKPOINT CLEANUP ERROR: {e}")
            
    def list_checkpoints(self):
        """Lista tutti i checkpoint disponibili"""
        checkpoints = []
        try:
            for item in os.listdir(self.checkpoint_dir):
                item_path = os.path.join(self.checkpoint_dir, item)
                if os.path.isdir(item_path) and item.startswith("checkpoint_"):
                    manifest_path = os.path.join(item_path, "manifest.json")
                    if os.path.exists(manifest_path):
                        with open(manifest_path, 'r') as f:
                            manifest = json.load(f)
                            checkpoints.append(manifest)
            
            # Ordina per data di creazione
            checkpoints.sort(key=lambda x: x['created_at'], reverse=True)
            return checkpoints
            
        except Exception as e:
            print(f"❌ Error listing checkpoints: {e}")
            return []
            
    def restore_checkpoint(self, checkpoint_name):
        """Ripristina da un checkpoint specifico"""
        checkpoint_path = os.path.join(self.checkpoint_dir, checkpoint_name)
        
        if not os.path.exists(checkpoint_path):
            print(f"❌ CHECKPOINT NOT FOUND: {checkpoint_name}")
            return False
            
        try:
            print(f"🔄 RESTORING CHECKPOINT: {checkpoint_name}")
            
            # 1. Backup stato attuale
            backup_name = f"pre_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            self.create_checkpoint()
            
            # 2. Ripristina database
            db_backup = os.path.join(checkpoint_path, "tickets.db")
            if os.path.exists(db_backup):
                shutil.copy2(db_backup, self.db_path)
                print("✅ Database ripristinato")
            
            # 3. Ripristina configurazioni
            for config_file in ["config.json", "restart.log"]:
                config_backup = os.path.join(checkpoint_path, config_file)
                if os.path.exists(config_backup):
                    shutil.copy2(config_backup, config_file)
                    print(f"✅ {config_file} ripristinato")
            
            print(f"🎉 CHECKPOINT RESTORED: {checkpoint_name}")
            return True
            
        except Exception as e:
            print(f"❌ RESTORE FAILED: {e}")
            return False
            
    def get_checkpoint_info(self, checkpoint_name):
        """Ottiene informazioni dettagliate su un checkpoint"""
        checkpoint_path = os.path.join(self.checkpoint_dir, checkpoint_name)
        manifest_path = os.path.join(checkpoint_path, "manifest.json")
        
        if not os.path.exists(manifest_path):
            return None
            
        try:
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)
                
            # Aggiungi informazioni sui file
            files = os.listdir(checkpoint_path)
            manifest['files'] = files
            manifest['size_mb'] = self._get_directory_size(checkpoint_path) / (1024 * 1024)
            
            return manifest
            
        except Exception as e:
            print(f"❌ Error getting checkpoint info: {e}")
            return None
            
    def _get_directory_size(self, directory):
        """Calcola dimensione directory in bytes"""
        total_size = 0
        try:
            for dirpath, dirnames, filenames in os.walk(directory):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    total_size += os.path.getsize(filepath)
        except:
            pass
        return total_size
        
    def export_checkpoint(self, checkpoint_name, export_path):
        """Esporta un checkpoint come archivio"""
        checkpoint_path = os.path.join(self.checkpoint_dir, checkpoint_name)
        
        if not os.path.exists(checkpoint_path):
            return False
            
        try:
            shutil.make_archive(export_path, 'zip', checkpoint_path)
            print(f"📦 CHECKPOINT EXPORTED: {export_path}.zip")
            return True
        except Exception as e:
            print(f"❌ EXPORT FAILED: {e}")
            return False
    
    def reset_all_checkpoints(self):
        """Reset completo di tutti i checkpoint"""
        try:
            if os.path.exists(self.checkpoint_dir):
                shutil.rmtree(self.checkpoint_dir)
                os.makedirs(self.checkpoint_dir, exist_ok=True)
                print("🔄 CHECKPOINT RESET: Tutti i checkpoint eliminati")
                
                # Crea immediatamente un nuovo checkpoint
                new_checkpoint = self.create_checkpoint()
                if new_checkpoint:
                    print(f"✅ NUOVO CHECKPOINT CREATO: {new_checkpoint}")
                return True
        except Exception as e:
            print(f"❌ RESET FAILED: {e}")
            return False

# Inizializza sistema globale
checkpoint_system = CheckpointSystem()

def start_checkpoint_system():
    """Avvia il sistema di checkpoint"""
    checkpoint_system.start_checkpoint_system()
    return checkpoint_system
