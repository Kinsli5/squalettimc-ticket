"""
Configuration management for the Discord Ticket Bot
"""
import json
import os
from typing import Dict, Any, Optional

class Config:
    def __init__(self, config_file='config.json'):
        self.config_file = config_file
        self.config = self.load_config()
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                print(f"⚠️ Warning: Invalid JSON in {self.config_file}, using defaults")
        
        return self.get_default_config()
    
    def save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"❌ Error saving config: {e}")
            return False
    
    def get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "bot": {
                "prefix": "!",
                "activity": "Gestione Ticket",
                "status": "online"
            },
            "ticket": {
                "default_category_name": "🎫 TICKETS",
                "ticket_name_format": "ticket-{counter:04d}",
                "close_after_hours": 24,
                "max_tickets_per_user": 3
            },
            "messages": {
                "ticket_created": "🎫 **Ticket Creato!**\\n\\nGrazie per aver aperto un ticket. Un membro dello staff ti risponderà al più presto.\\n\\n**Per favore compila il modulo qui sotto con le informazioni richieste.**",
                "ticket_closed": "🔒 **Ticket Chiuso**\\n\\nQuesto ticket è stato chiuso. Se hai bisogno di ulteriore assistenza, apri un nuovo ticket.",
                "ticket_close_confirmation": "⚠️ **Conferma Chiusura**\\n\\nSei sicuro di voler chiudere questo ticket?\\n\\nQuesta azione non può essere annullata.",
                "no_permission": "❌ Non hai i permessi per eseguire questa azione.",
                "ticket_limit_reached": "❌ Hai raggiunto il limite massimo di ticket aperti ({limit}).",
                "invalid_channel": "❌ Questo comando può essere utilizzato solo nei canali ticket."
            },
            "embeds": {
                "color_primary": 0x00ff00,
                "color_warning": 0xffaa00,
                "color_error": 0xff0000,
                "color_info": 0x0099ff
            },
            "permissions": {
                "ticket_access": ["staff", "admin", "moderator"],
                "close_others_tickets": ["admin", "moderator"],
                "setup_permissions": ["admin"]
            }
        }
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value using dot notation"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any) -> bool:
        """Set configuration value using dot notation"""
        keys = key.split('.')
        config = self.config
        
        # Navigate to the parent of the target key
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        # Set the final key
        config[keys[-1]] = value
        return self.save_config()
    
    def get_prefix(self) -> str:
        """Get bot command prefix"""
        return self.get('bot.prefix', '!')
    
    def get_embed_color(self, color_type: str = 'primary') -> int:
        """Get embed color by type"""
        return self.get(f'embeds.color_{color_type}', 0x00ff00)
    
    def get_message(self, message_key: str) -> str:
        """Get configured message"""
        return self.get(f'messages.{message_key}', f'Message not found: {message_key}')
    
    def get_ticket_config(self) -> Dict[str, Any]:
        """Get ticket-specific configuration"""
        return self.get('ticket', {})
    
    def update_config(self, updates: Dict[str, Any]) -> bool:
        """Update multiple configuration values"""
        try:
            def deep_update(base_dict, update_dict):
                for key, value in update_dict.items():
                    if isinstance(value, dict) and key in base_dict and isinstance(base_dict[key], dict):
                        deep_update(base_dict[key], value)
                    else:
                        base_dict[key] = value
            
            deep_update(self.config, updates)
            return self.save_config()
        except Exception as e:
            print(f"❌ Error updating config: {e}")
            return False
    
    def reset_to_defaults(self) -> bool:
        """Reset configuration to defaults"""
        self.config = self.get_default_config()
        return self.save_config()
    
    def validate_config(self) -> bool:
        """Validate configuration integrity"""
        required_sections = ['bot', 'ticket', 'messages', 'embeds', 'permissions']
        
        for section in required_sections:
            if section not in self.config:
                print(f"❌ Missing required config section: {section}")
                return False
        
        return True
